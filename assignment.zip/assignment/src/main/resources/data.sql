#drop table if exists student_db.user_role;
#drop table if exists student_db.role;
#drop table if exists student_db.user;
#drop table if exists student_db.student;

insert into student(`id`, `name`, `email`, `mobile`)
values(1,'Rohit', 'rohitraj.r@hotmail.com', '8744940280');

insert into student(`id`, `name`, `email`, `mobile`)
values(2,'Mohit', 'mohit@hotmail.com', '8744940280');

INSERT INTO `student_db`.`user` (`user_id`, `accountNonExpired`, `accountNonLocked`, `credentialsNonExpired`, `enabled`, `password`, `username`) VALUES ('1', true, true, true, true, '$2a$12$G8FXvjiZ5yjlAZIvB/BMweghr/NlaxZRONLSgI/0HoaW1F7zxAIhm', 'rohit');
INSERT INTO `student_db`.`user` (`user_id`, `accountNonExpired`, `accountNonLocked`, `credentialsNonExpired`, `enabled`, `password`, `username`) VALUES ('2', true, true, true, true, '$2a$12$G8FXvjiZ5yjlAZIvB/BMweghr/NlaxZRONLSgI/0HoaW1F7zxAIhm', 'admin');

INSERT INTO `student_db`.`role` (`role_id`, `roleName`) VALUES ('1', 'USER');
INSERT INTO `student_db`.`role` (`role_id`, `roleName`) VALUES ('2', 'ADMIN');

INSERT INTO `student_db`.`user_role` (`user_id`, `role_id`) VALUES ('1', '1');
INSERT INTO `student_db`.`user_role` (`user_id`, `role_id`) VALUES ('2', '2');
