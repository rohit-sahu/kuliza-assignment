package com.kuliza.assignment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kuliza.assignment.model.Student;

/**
 * Repository for Student Entity, Useful for Database operations.
 * 
 * @author 	rohit
 * @version 1.0
 * @since	2019-08-28
 */
public interface StudentRepository extends JpaRepository<Student, Long> {

}
