package com.kuliza.assignment.utils;

public class RequestPathUrls {

	public static final String HOME = "/";
	
	public static final String BASE_API = HOME + "api" + HOME + "v1";
	
	public static final String STUDENT = BASE_API + HOME + "student";
}
