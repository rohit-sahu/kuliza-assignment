package com.kuliza.assignment.service.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.kuliza.assignment.model.Student;
import com.kuliza.assignment.repository.StudentRepository;
import com.kuliza.assignment.service.StudentService;

/**
 * Implementation of Student service class.
 * 
 * @author 	rohit
 * @version 1.0
 * @since	2019-08-28
 */
@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository studentRepository;

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public Student saveOrUpdate(Student student) {
		return studentRepository.save(student);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public Student findStudent(Long id) {
		Optional<Student> optional = studentRepository.findById(id);
		if (optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public List<Student> findAllStudent() {
		return studentRepository.findAll();
	}
}
