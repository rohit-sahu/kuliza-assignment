package com.kuliza.assignment.service;

import java.util.List;

import com.kuliza.assignment.model.Student;

/**
 * Service for {@link Student} entity.
 * 
 * @author rohit
 * @version 1.0
 * @since 2019-08-28
 * @see {@link Student}
 */
public interface StudentService {

	public Student saveOrUpdate(Student student);

	public Student findStudent(Long id);

	public List<Student> findAllStudent();
}
