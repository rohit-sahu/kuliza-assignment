package com.kuliza.assignment.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kuliza.assignment.model.User;

public interface UserRepository extends JpaRepository<User, Long> {

	public Optional<User> findByusername(String username);
}
