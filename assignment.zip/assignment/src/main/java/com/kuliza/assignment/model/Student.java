package com.kuliza.assignment.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Entity of Student.
 * 
 * @author 	rohit
 * @version 1.0
 * @since	2019-08-28
 * @see		{@link Serializable}
 */
@Entity
@Table(name = "student")
@ApiModel(description = "All details about the student.")
public class Student implements Serializable {

	private static final long serialVersionUID = 4517360826481867595L;

	@Id
	@Column(name = "id")
	@Digits(integer = Integer.MAX_VALUE, fraction = 0)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@ApiModelProperty(notes = "Unique student id")
	private Long id;

	@NotBlank(message = "Name is mandatory")
	@ApiModelProperty(notes = "Name should have atleast 2 characters")
	@Size(min = 2, max = 30, message = "Name should have atleast 2 characters")
	@Column(name = "name", length = 30)
	private String name;
	
	@Email(regexp = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$")
	@NotBlank(message = "Email is mandatory")
	@ApiModelProperty(notes = "Email should be valid")
	@Column(name = "email", nullable = false, unique = true, updatable = true, length = 50)
	private String email;

	@NotEmpty
	@NotBlank(message = "Mobile number is mandatory")
	@ApiModelProperty(notes = "Mobile Number should have atleast 10 characters")
	@Size(min = 10, max = 15, message = "Mobile Number should have atleast 10 characters")
	@Column(name = "mobile", length = 15)
	private String mobile;

	public Student() {
		super();
	}

	public Student(Long id, String name, String mobile) {
		super();
		this.id = id;
		this.name = name;
		this.mobile = mobile;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((mobile == null) ? 0 : mobile.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (mobile == null) {
			if (other.mobile != null)
				return false;
		} else if (!mobile.equals(other.mobile))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", email=" + email + ", mobile=" + mobile + "]";
	}
}
